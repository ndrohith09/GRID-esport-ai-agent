### Top Teams (6)

97      7
79      6
96      6
1079    5
337     5
1611    4


## Top players with repeated teams (10)

10612    7
10636    7
1195     7
2348      7
272      7
2513     7
1193     7
297      7
2358     7
2340     7

74432    7

## Player consts
maxHealth = 100
teamHeadshots = 0 (for these players)

## Series ID

2819695    2
2843069    2
2843067    2
2843063    2
2843070    2
2819700    2
2843071    2
2843068    2
2843061    2
2819704    2
2843066    2
2843060    2
2843062    2
2819694    2
2843064    2
2819703    2
2819701    2
2819698    1
2843065    1
2819696    1
2819699    1
2819705    1


series_id, player_id, sequence number, stats